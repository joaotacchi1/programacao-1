#include <stdio.h>

int main(){
    
    printf("Número de bytes de char: %lu\n", sizeof(char));
    printf("Número de bytes em int: %lu\n", sizeof(int));
    printf("Número de bytes em float: %lu\n", sizeof(float));
    printf("Número de bytes em double: \n", sizeof(double));
    
    
    return 0;
}