//Na passagem de valor é feita uma cópia da variável declarada onde
//esta pode ser usada e alterada dentro da função sem afetar a variável da qual ela foi gerada. 
//Já na passagem por referência é quando uma função precisa ser capaz de alterar os valores das variáveis usadas como argumentos,
//onde os parâmetros precisam ser explicitamente declarados como tipos ponteiros e que são usadas referências