//p++ incrementa +1(4 bytes) no endereço de memoria da variável p
//(*p)++ incrementa +1(4 bytes) no conteúdo contido naquele endereço de memória da variável p
//*(p++) primeiramente incremente +1(4 bytes) no endereço de memoria da variavel p, e depois coloca o conteúdo dessa
//variável incrementada