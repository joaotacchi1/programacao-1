#include <stdio.h>

int main(){

   printf("Bom dia/Boa tarde/Boa noite Filipe\n");
   printf("A diferenca entre o for e o while, e que o for e usado");
   printf(" para quando se tem numero de interacoes ja avisado,\nja intencionado\n");
   printf("Ja o while e usado para quando vc tem uma especulacao de quantas vezes vao ser repetidas\n");
   printf("o algoritmo, mas nao tem certeza de quantas vezes vao ser");

    return 0;
}
